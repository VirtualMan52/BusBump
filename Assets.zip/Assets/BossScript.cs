﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BossScript : MonoBehaviour
{
    public PlayerData plrData;
    public DialogScript dialog;
    public Animator anim;
    public int step = 0;
    public List<GameObject> toDelete;

    void Awake()
    {
        plrData = GameObject.Find("PlayerData").GetComponent<PlayerData>();
        dialog = GameObject.Find("Dialog").GetComponent<DialogScript>();
    }

    private void Update()
    {
        if (step == 0 && plrData.time > 9.66f && plrData.tookTest == false)
        {
            foreach (GameObject o in toDelete)
            {
                Destroy(o);
            }
            transform.position = GameObject.Find("Player").transform.position;
            GameObject.Find("Player").GetComponent<PlayerScript>().canMove = false;
            GameObject.Find("Player").GetComponent<PlayerScript>().movedirection = Vector3.zero;
            anim.SetBool("go", true);
            dialog.Name = "Principal";
            dialog.Text = "Isn't it time to go to class ?";
            step = 1;
        } else if (step == 1)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                dialog.Text = "You have a test to take.";
                step = 2;
            }
            if (plrData.time > 9.7f)
            {
                Time.timeScale = 0;
            }
        } else if (step == 2)
        {
            if (plrData.time > 9.7f)
            {
                Time.timeScale = 0;
            }
            if (Input.GetKeyDown(KeyCode.E))
            {
                Time.timeScale = 1;
                SceneManager.LoadScene(2);
            }
        }
    }
}
