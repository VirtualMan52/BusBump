﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BusExitManager : MonoBehaviour
{
    public PlayerData plrData;
    public int step = -1;
    public string state = "read";
    public List<string> actions;
    public DialogScript dialog;
    public Animator anim;
    public Animator anim2;
    private float timecounter = 0;

    private void Awake()
    {
        plrData = GameObject.Find("PlayerData").GetComponent<PlayerData>();
        plrData.run += 1;
        if (plrData.run == 1)
        {
            actions.Add("Urgh... My head... That was a hard bump.");
            actions.Add("I must've knocked out.");
            actions.Add("No matter. We'll probably be at school.");
        }
        else if (plrData.run == 2)
        {
            actions.Add("Gosh... what's with all these bumps...?");
            actions.Add("I'll probably wake up when I'm back at home.");
        }
        else if (plrData.run == 3)
        {
            actions.Add("I seem to be stuck in some kind of loop...");
            actions.Add("I somehow need to break it.");
            actions.Add("Maybe by... how do they do it in the movies ?");
            actions.Add("... They... uncover some kind of mystery and the loop is broken, or something...");
            actions.Add("Maybe... if I discover why the teachers are gone...");
            actions.Add("It'll break the loop !");
            actions.Add("...Seriously, why are they all gone anyway ?");
            actions.Add("Did they get murdered ?");
            actions.Add("That would be scary, and time-consuming for a COMPO game.");
            actions.Add("How would I do this...");
            actions.Add("Generally when big things happen, it's in the gymnasium.");
            actions.Add("That's probably where I need to go.");
            actions.Add("To go there, I have to go to the cafeteria.");
            actions.Add("But it's closed until 10:30 and there would be too many witnesses.");
            actions.Add("I need to go there early.");
            actions.Add("There's another way to get into the cafeteria.");
            actions.Add("If I go by the rightmost door, I should be able to get into the cafeteria by the storage room.");
            actions.Add("But that door is locked by a code...");
            actions.Add("Maybe they wrote the code somewhere in the teacher's office, the rightmost door.");
            actions.Add("URGH ! This door is locked too, dummy.");
            actions.Add("... Wait. The janitor must have the keys !");
            actions.Add("They leave them in their coat.");
            actions.Add("I can nab the key before they go home at 9:30 !");
            actions.Add("I also can't forget to take my test.");
            actions.Add("Alright.");
            actions.Add("Get Keys.");
            actions.Add("Take test.");
            actions.Add("Open door.");
            actions.Add("It's that easy.");
            actions.Add("I can always restart if I miss something.");
        }
        else if (plrData.run >= 4)
        {
            actions.Add("Alright.");
            actions.Add("Get Keys.");
            actions.Add("Take test.");
            actions.Add("Open door.");
            actions.Add("It's that easy.");
        }
    }

    private void Update()
    {
        if (state == "read")
        {
            step += 1;
            if (step == actions.Count)
            {
                dialog.Text = "";
                state = "wait";
                anim.SetBool("go", true);
                anim2.SetBool("go", true);
            } else
            {
                dialog.Name = "You";
                dialog.Text = actions[step];
                state = "waitForInteract";
            }
        } else if (state == "waitForInteract")
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                state = "read";
            }
        } else if (state == "wait")
        {
            timecounter += Time.deltaTime;
            if (timecounter >= 2f)
            {
                plrData.tookTest = false;
                plrData.backpack = new List<string>();
                plrData.time = 9.33f;
                SceneManager.LoadScene(1);
            }
        }
    }
}
