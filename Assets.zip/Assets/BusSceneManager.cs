﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BusSceneManager : MonoBehaviour
{
    public float counter;
    void Update()
    {
        counter += Time.deltaTime;
        if (counter >= 4)
        {
            SceneManager.LoadScene(4);
        }
    }
}
