﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CafeteriaManager : MonoBehaviour
{
    public PlayerData plrData;
    public GameObject Cafeteria;
    public GameObject cafeBlocker;

    void Awake()
    {
        plrData = GameObject.Find("PlayerData").GetComponent<PlayerData>();
    }

    void Update()
    {
        if (plrData.time >= 10.5)
        {
            Cafeteria.SetActive(true);
            cafeBlocker.SetActive(false);
        }
    }
}
