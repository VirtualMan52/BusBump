﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoatHangerScript : MonoBehaviour
{
    public PlayerData plrData;
    public Animator anim;

    void Awake()
    {
        plrData = GameObject.Find("PlayerData").GetComponent<PlayerData>();
    }

    private void Update()
    {
        if (plrData.time > 9.5f)
        {
            anim.SetBool("go",true);
        }
    }
}
