﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CodeScript : MonoBehaviour
{
    public string code;
    public GameObject toDelete;

    public void OnClick()
    {
        if (GetComponent<TMP_InputField>().text == code)
        {
            Destroy(toDelete);
        }
        GameObject.Find("Player").GetComponent<PlayerScript>().canMove = true;
        gameObject.SetActive(false);
    }
}
