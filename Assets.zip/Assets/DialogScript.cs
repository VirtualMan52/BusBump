﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DialogScript : MonoBehaviour
{
    public string Text;
    public string Name;
    public TMP_Text CurrentText;
    public TMP_Text NameText;
    public GameObject Box;

    private void Update()
    {
        if (Text.StartsWith(CurrentText.text))
        {
            if (Text.Length != CurrentText.text.Length)
            {
                char c = Text[CurrentText.text.Length];
                CurrentText.text += c;
                Box.SetActive(true);
                NameText.text = Name;
            }
        } else
        {
            if (Text == "")
            {
                CurrentText.text = "";
                Box.SetActive(false);
            } else
            {
                CurrentText.text = "";
                if (Text.Length != CurrentText.text.Length)
                {
                    char c = Text[CurrentText.text.Length];
                    CurrentText.text += c;
                }
            }
        }
    }
}
