﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndingManager : MonoBehaviour
{
    public string state = "wait";
    public float timecounter = 0;
    public int step;
    public List<string> actions;
    public DialogScript dialog;
    public Animator anim1;
    public Animator anim2;
    public GameObject back;
    public GameObject unc1;
    public GameObject unc2;

    void Update()
    {
        if (state == "wait")
        {
            timecounter += Time.deltaTime;
            if (timecounter >= 2f)
            {
                state = "read";
            }
        } else if (state == "wait2")
        {
            timecounter += Time.deltaTime;
            if (timecounter >= 2f)
            {
                back.SetActive(true);
                unc1.SetActive(true);
                timecounter = -3f;
                state = "wait3";
            }
        } else if (state == "wait3")
        {
            timecounter += Time.deltaTime;
            if (timecounter >= 2f)
            {
                back.SetActive(true);
                unc1.SetActive(false);
                unc2.SetActive(true);
            }
        } else if (state == "waitBump")
        {
            timecounter += Time.deltaTime;
            if (timecounter >= 2f)
            {
                anim1.SetBool("go", true);
                anim2.SetBool("go", true);
                timecounter = 1f;
                state = "wait2";
            }
        } else if (state == "read")
        {
            step += 1;
            if (step == actions.Count)
            {
                dialog.Text = "";
                state = "waitBump";
            }
            else
            {
                dialog.Name = "You";
                dialog.Text = actions[step];
                state = "waitForInteract";
            }
        }
        else if (state == "waitForInteract")
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                state = "read";
            }
        }
    }
}
