﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GymnasiumManager : MonoBehaviour
{
    public string state = "wait";
    public float timecounter = 0;
    public int step;
    public List<string> actions;
    public DialogScript dialog;

    void Update()
    {
        if (state == "wait")
        {
            timecounter += Time.deltaTime;
            if (timecounter >= 2f)
            {
                state = "read";
            }
        }
        else if(state == "wait2")
        {
            timecounter += Time.deltaTime;
            if (timecounter >= 2f)
            {
                SceneManager.LoadScene(6);
            }
        } else if (state == "read")
        {
            step += 1;
            if (step == actions.Count)
            {
                dialog.Text = "";
                timecounter = -1f;
                state = "wait2";
            }
            else
            {
                if (actions[step].StartsWith("T*"))
                {
                    actions[step] = actions[step].Replace("T*","");
                    dialog.Name = "Teacher";
                } else
                {
                    dialog.Name = "You";
                }
                dialog.Text = actions[step];
                state = "waitForInteract";
            }
        }
        else if (state == "waitForInteract")
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                state = "read";
            }
        }
    }
}
