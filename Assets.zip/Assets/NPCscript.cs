﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCscript : MonoBehaviour
{
    public Vector3 movedirection;
    public string state = "Move";
    public Rigidbody2D rb;
    public Animator anim;

    private void Awake()
    {
        anim = gameObject.GetComponent<Animator>();
    }

    void Update()
    {
        if (state == "Move")
        {
            if (movedirection.x != 0 || movedirection.y != 0)
            {
                anim.SetBool("Walking", true);
                if (movedirection.x == 1)
                {
                    anim.SetInteger("Direction", 2);
                }
                else if (movedirection.x == -1)
                {
                    anim.SetInteger("Direction", 1);
                }
                else if (movedirection.y == 1)
                {
                    anim.SetInteger("Direction", 3);
                }
                else if (movedirection.y == -1)
                {
                    anim.SetInteger("Direction", 4);
                }
            }
            else
            {
                anim.SetBool("Walking", false);
            }
        }
    }
}
