﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerData : MonoBehaviour
{
    public float time;
    public List<string> backpack;
    public bool tookTest;
    public int run;

    public void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
    }
    public void Update()
    {
        time += Time.deltaTime / 100f;
    }
}
