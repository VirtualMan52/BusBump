﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    public Vector3 movedirection;
    public float plrSpeed;
    public string state = "Move";
    public bool canMove = true;
    public Rigidbody2D rb;
    public Animator anim;

    void Update()
    {
        if (state == "Move")
        {
            GetInput();
            rb.velocity = new Vector3(movedirection.x * plrSpeed * Time.deltaTime, movedirection.y * plrSpeed * Time.deltaTime);
            if (movedirection.x != 0 || movedirection.y != 0)
            {
                anim.SetBool("Walking", true);
                if (movedirection.x == 1)
                {
                    anim.SetInteger("Direction",2);
                } else if (movedirection.x == -1)
                {
                    anim.SetInteger("Direction", 1);
                } else if (movedirection.y == 1)
                {
                    anim.SetInteger("Direction", 3);
                } else if (movedirection.y == -1)
                {
                    anim.SetInteger("Direction", 4);
                }
            } else
            {
                anim.SetBool("Walking", false);
            }
        }
    }

    void GetInput()
    {
        if (canMove)
        {
            movedirection = new Vector3(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"), 0f);
        }
    }
}
