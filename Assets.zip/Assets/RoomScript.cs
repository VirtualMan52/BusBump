﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomScript : MonoBehaviour
{
    public List<GameObject> list;
    public float transparency = 1f;
    public float currenttransparency = 1f;

    private void Update()
    {
        if (transparency > currenttransparency)
        {
            currenttransparency += 0.05f;
        } else if (transparency < currenttransparency)
        {
            currenttransparency -= 0.05f;
        }
        if (currenttransparency < 0.10f)
        {
            foreach (GameObject obj in list)
            {
                Color c = obj.GetComponent<SpriteRenderer>().material.color;
                c.a = 0f;
                obj.GetComponent<SpriteRenderer>().material.color = c;
            }
        } else if (currenttransparency > 0.90f)
        {
            foreach (GameObject obj in list)
            {
                Color c = obj.GetComponent<SpriteRenderer>().material.color;
                c.a = 1f;
                obj.GetComponent<SpriteRenderer>().material.color = c;
            }
        } else {
            foreach (GameObject obj in list)
            {
                Color c = obj.GetComponent<SpriteRenderer>().material.color;
                c.a = currenttransparency;
                obj.GetComponent<SpriteRenderer>().material.color = c;
            }
        }
    }

    private void Open()
    {
        transparency = 0;
    }

    private void Close()
    {
        transparency = 1;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            Open();
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            Close();
        }
    }
}
