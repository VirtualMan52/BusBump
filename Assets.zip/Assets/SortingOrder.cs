﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SortingOrder : MonoBehaviour
{
    [SerializeField] private int baseLayer = 5000;
    [SerializeField] private int offset = 0;
    [SerializeField] private bool runOnce = true;
    [SerializeField] List<GameObject> plus = null;
    private Renderer myRenderer;

    private void Awake()
    {
        myRenderer = gameObject.GetComponent<Renderer>();
    }

    private void LateUpdate()
    {
        myRenderer.sortingOrder = (int)(baseLayer - transform.position.y - offset);
        if (plus.Count > 0)
        {
            foreach (GameObject p in plus)
            {
                p.GetComponent<Renderer>().sortingOrder = (int)(baseLayer - transform.position.y - offset);
            }
        }
        if (runOnce == true)
        {
            Destroy(this);
        }
    }

}
