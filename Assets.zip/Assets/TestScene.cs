﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestScene : MonoBehaviour
{
    public PlayerData plrData;
    public GameObject cutscene;
    public GameObject teacher;

    void Awake()
    {
        plrData = GameObject.Find("PlayerData").GetComponent<PlayerData>();
        if (plrData.tookTest == false)
        {
            cutscene.SetActive(true);
        }
    }
}
