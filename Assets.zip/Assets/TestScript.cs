﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestScript : MonoBehaviour
{
    public void OnClick()
    {
        GameObject.Find("Player").GetComponent<PlayerScript>().canMove = true;
        GameObject.Find("PlayerData").GetComponent<PlayerData>().tookTest = true;
        Destroy(gameObject);
    }
}
