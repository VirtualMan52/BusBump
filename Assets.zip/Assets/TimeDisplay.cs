﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TimeDisplay : MonoBehaviour
{
    public PlayerData plrData;
    public TMP_Text display;

    private void Awake()
    {
        plrData = GameObject.Find("PlayerData").GetComponent<PlayerData>();
    }

    private void Update()
    {
        float hours = Mathf.Floor(plrData.time);
        float minutes = plrData.time % hours * 60;
        if (minutes > 59.4f)
        {
            hours += 1f;
            minutes = 0f;
        }
        display.text = string.Format(hours.ToString() + ":{0:00}", minutes);
    }
}
