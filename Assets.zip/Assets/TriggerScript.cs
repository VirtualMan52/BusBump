﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TriggerScript : MonoBehaviour
{
    public bool interact;
    public DialogScript dialog;
    public List<string> Actions;
    public bool touchingPlr;
    public string state = "notTriggered";
    public int action = 0;
    public PlayerData plrData;

    void Awake()
    {
        dialog = GameObject.Find("Dialog").GetComponent<DialogScript>();
        plrData = GameObject.Find("PlayerData").GetComponent<PlayerData>();
    }

    void Update()
    {
        if (touchingPlr && state == "notTriggered")
        {
            if (interact)
            {
                if (Input.GetKeyDown(KeyCode.E))
                {
                    action = -1;
                    state = "readAction";
                }
            } else
            {
                action = -1;
                state = "readAction";
            }
        } else if (state == "readAction")
        {
            action += 1;
            if (Actions.Count > action)
            {
                if (Actions[action].StartsWith("Text"))
                {
                    state = "readText";
                } else if (Actions[action].StartsWith("CheckObject"))
                {
                    state = "readObject";
                } else if (Actions[action].StartsWith("Delete"))
                {
                    state = "readDelete";
                }
                else if (Actions[action].StartsWith("AddObject"))
                {
                    state = "readAddObject";
                }
                else if (Actions[action].StartsWith("CheckRun"))
                {
                    state = "readERun";
                }
                else if (Actions[action].StartsWith("CheckRunEquals"))
                {
                    state = "readERun";
                }
                else if (Actions[action].StartsWith("Time"))
                {
                    state = "readTime";
                }
                else if (Actions[action].StartsWith("Freeze"))
                {
                    state = "readFreeze";
                }
                else if (Actions[action].StartsWith("LoadScene"))
                {
                    state = "readScene";
                }
                else if (Actions[action] == "Test")
                {
                    state = "Test";
                }
                else if (Actions[action] == "TookTest")
                {
                    state = "TookTest";
                }
                else if (Actions[action] == "TookTestFalse")
                {
                    state = "TookTestFalse";
                }
                if (!Actions[action].StartsWith("Text"))
                {
                    dialog.Text = "";
                }
            } else
            {
                dialog.Text = "";
                state = "notTriggered";
            }
        } else if (state == "readText")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            dialog.Name = components[1];
            dialog.Text = components[2];
            state = "waitForInteract";
        } else if (state == "readObject")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            if (plrData.backpack.Contains(components[1]))
            {
                state = "readAction";
            } else
            {
                state = "notTriggered";
            }
        }
        else if (state == "readRun")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            int max;
            int.TryParse(components[1], out max);
            if (plrData.run >= max)
            {
                state = "readAction";
            }
            else
            {
                state = "notTriggered";
                Destroy(gameObject);
            }
        }
        else if (state == "TookTest")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            if (plrData.tookTest == true)
            {
                state = "readAction";
            }
            else
            {
                state = "notTriggered";
                Destroy(gameObject);
            }
        }
        else if (state == "TookTestFalse")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            if (plrData.tookTest == false)
            {
                state = "readAction";
            }
            else
            {
                state = "notTriggered";
                Destroy(gameObject);
            }
        }
        else if (state == "readERun")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            int max;
            int.TryParse(components[1], out max);
            Debug.Log(max);
            if (plrData.run == max)
            {
                state = "readAction";
            }
            else
            {
                state = "notTriggered";
                Destroy(gameObject);
            }
        }
        else if (state == "readDelete")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            Destroy(GameObject.Find(components[1]));
            state = "readAction";
        }
        else if (state == "readTime")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            float min;
            float max;
            float.TryParse(components[1], out min);
            float.TryParse(components[2], out max);
            if (plrData.time > min && plrData.time < max)
            {
                state = "readAction";
            } else
            {
                state = "notTriggered";
            }
        } else if (state == "readAddObject")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            plrData.backpack.Add(components[1]);
            state = "readAction";
        } else if (state == "readFreeze")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            if (components[1] == "true")
            {
                GameObject.Find("Player").GetComponent<PlayerScript>().canMove = true;
            } else
            {
                GameObject.Find("Player").GetComponent<PlayerScript>().canMove = false;
                GameObject.Find("Player").GetComponent<PlayerScript>().movedirection = Vector3.zero;
            }
            state = "readAction";
        } else if (state == "readScene")
        {
            string[] components = Actions[action].Split(char.Parse("*"));
            int n;
            int.TryParse(components[1], out n);
            SceneManager.LoadScene(n);
        } else if (state == "Test")
        {
            GameObject.Find("Test").GetComponent<ChildScript>().child.SetActive(true);
            state = "readAction";
        } else if (state == "waitForInteract")
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                state = "readAction";
            }
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            touchingPlr = true;
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.name == "Player")
        {
            touchingPlr = false;
        }
    }
}
